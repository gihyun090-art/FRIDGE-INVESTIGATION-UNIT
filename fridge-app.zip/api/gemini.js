// Vercel 서버리스 함수
// 브라우저는 이 함수만 호출하고, 실제 구글 API 키는 이 파일(서버) 안에서만 사용됩니다.
// 배포 후 Vercel 대시보드 > Settings > Environment Variables 에 GOOGLE_API_KEY를 등록해야 동작합니다.

module.exports = async (req, res) => {
  if (req.method !== "POST") {
    res.status(405).json({ error: "POST 요청만 지원합니다." });
    return;
  }

  const apiKey = process.env.GOOGLE_API_KEY;
  if (!apiKey) {
    res.status(500).json({ error: "서버에 GOOGLE_API_KEY 환경변수가 설정되지 않았습니다." });
    return;
  }

  try {
    const { contents } = req.body || {};
    if (!contents) {
      res.status(400).json({ error: "contents 값이 필요합니다." });
      return;
    }

    const model = "gemini-3.5-flash";
    const url = "https://generativelanguage.googleapis.com/v1beta/models/" + model + ":generateContent";

    const geminiRes = await fetch(url, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
        "x-goog-api-key": apiKey
      },
      body: JSON.stringify({ contents })
    });

    const data = await geminiRes.json();

    if (!geminiRes.ok) {
      const message = (data && data.error && data.error.message) || "Gemini API 오류가 발생했습니다.";
      res.status(geminiRes.status).json({ error: message });
      return;
    }

    const candidate = data.candidates && data.candidates[0];
    const parts = (candidate && candidate.content && candidate.content.parts) || [];
    const text = parts.map(p => p.text || "").join("\n");

    res.status(200).json({ text });
  } catch (err) {
    res.status(500).json({ error: err.message || "알 수 없는 서버 오류" });
  }
};
